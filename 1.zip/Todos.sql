DROP TABLE IF EXISTS dbtodos ;
CREATE DATABASE dbtodos;
USE dbtodos;
DROP TABLE IF EXISTS tbltodos;
CREATE TABLE tbltodos 
(
	TodoID	INT,
	 TodoName VARCHAR(50),
	completed  VARCHAR(80),
	notes  	VARCHAR(50)
	
);
INSERT INTO tbltodos VALUES 	('200279010', 'shuxiangwu','student','a student');
SELECT * FROM tbltodos;  