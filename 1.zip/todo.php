<?php

/*Class TodoList and add information as a table or delete and save*/
    class TodoList
    {
        public function addItem($item)
        {
            $_SESSION['TodoList'][] = $item;
        }

        public function editItem($position, $item)
        {
            $_SESSION['TodoList'][$position - 1] = $item;
        }

        public function removeItem($position)
        {
            unset($_SESSION['TodoList'][$position - 1]);
        }
    }

    $list = new TodoList();
    session_start();

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        if (!empty($_POST['addItem'])) {
            $list->addItem($_POST['addItem']);
        }
        if (!empty($_POST['editPosition'])) {
            $list->editItem($_POST['editPosition'], $_POST["editItem{$_POST['editPosition']}"]);
        }
        if (!empty($_POST['removePosition'])) {
            $list->removeItem($_POST['removePosition']);
        }
    }
$dbt= new PDO("mysql:localhost=;dbname=dbtodos", "root", "wsx960827");
$dbt->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $sql = 'SELECT * FROM tbltodos';
  $tables = $dbt->query($sql);
  $row_count = $tables->rowCount();
  $dbt = null;
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>A To Do List</title>
</head>
<body>
    <header>
        <form name="logout" action="logout.php">
            welcome TO DO LIST 
            <button> logoff</button>
        </form>
    </header>
    <p>
        <form method="post" action="todo.php">
            <input name="addItem" type="text" placeholder="information？">
            <button>add</button>
        </form>
    </p>
    <form method="post" action="todo.php">
        <?php foreach ((array)$_SESSION['TodoList'] as $key => $item): ?>
            <input type="checkbox">
            <input name="editItem<?= $key + 1 ?>" type="text" value="<?= $item ?>">
            <button name="editPosition" value="<?= $key + 1 ?>">save</button>
            <button name="removePosition" value="<?= $key + 1 ?>">delete</button>
            <br />
        <?php endforeach ?>
</body>
</html>
