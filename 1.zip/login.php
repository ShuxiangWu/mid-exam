<?php
/*design login information*/
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = empty($_POST['username']) ? '' : $_POST['username'];
        $password = empty($_POST['password']) ? '' : $_POST['password'];
        if ($username == 'shuxiangwu' && $password == 'shuxiangwu') {
            session_start();
            $_SESSION['username'] = $username;
            header('Location: todo.php');
        } else {
            $errorMessage = "something wrong！";
            header('Location: index.php');
        }
    }
?>
