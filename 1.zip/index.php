<?php
    include 'login.php';

/*write body*/
?>

<!DOCTYPE html>

<html lang="zh">
<head>
     <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.2/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-aNUYGqSUL9wG/vP7+cWZ5QOM4gsQou3sBfWRr/8S3R1Lv0rysEmnwsRKMbhiQX/O" crossorigin="anonymous">
    <link rel="stylesheet" href="css/main.css">
    <meta charset="utf-8">
    <title>login</title>
</head>
<body>
    
    <h1 class="header">TO DO LIST!</h1>
    <ul class="items">
    
                <li>This is assignment 1, to do list.</li>
                <li>This is Shuxiang WU 200279010. </li>
            </ul>
    <p style="color:red">
        <?php
            if (isset($errorMessage)) {
                echo $errorMessage;
                unset($errorMessage);
            }
        ?>
    </p>
    <form name="login" method="post" action="login.php">
        <p>
            <label>name：</label>
            <input name="username" type="text">
        </p>
        <p>
            <label>password：</label>
            <input name="password" type="password">
        </p>
        <button>login</button>
    </form>
    <p style="color:grey">* name and password are both shuxiangwu.</p>
</body>
</html>
