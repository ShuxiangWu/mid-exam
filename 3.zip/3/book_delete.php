<?php
include_once('database.php');

/*//////////////////////*/
/* YOUR CODE GOES HERE */
/*/////////////////////*/
$bookTitle = $_GET["bookTitle"]; // assigns the gameID from the URL

if($bookTitle != false) {
    $query = "DELETE FROM books WHERE Id = :book_Id";
    $statement = $db->prepare($query);
    $statement->bindValue(":book_Id", $bookID);
    $success = $statement->execute(); // execute the prepared query
    $statement->closeCursor(); // close off database
}

// redirect to index page
header('Location: index.php');

?>
